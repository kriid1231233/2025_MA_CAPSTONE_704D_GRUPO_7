<?php
// --- 1. CONFIGURACIÓN DE LA BASE DE DATOS ---
$servername = "localhost";
$username = "zhwmxmyk_zhwmxmyk";
$password = "*8IS2G2fy6aS@2&g";
$dbname = "zhwmxmyk_form_datos";

// --- 2. CONEXIÓN ---
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Error de conexión: " . $conn->connect_error);
}

// --- 3. SUBIDA DE LA IMAGEN ---
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["imagen"]["name"]);

if (move_uploaded_file($_FILES["imagen"]["tmp_name"], $target_file)) {
    
    // --- 4. OBTENER DATOS DEL FORMULARIO ---
    $nombre = $_POST['nombre'];
    $telefono = $_POST['telefono'];
    $noticia = $_POST['noticia']; // <-- OBTENEMOS EL NUEVO DATO
    $ruta_imagen = $target_file;

    // --- 5. INSERTAR DATOS EN LA BASE DE DATOS ---
    // Actualizamos la consulta y los tipos de parámetros ("ssss" para 4 strings)
    $stmt = $conn->prepare("INSERT INTO registros (nombre, telefono, noticia, ruta_imagen) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $nombre, $telefono, $noticia, $ruta_imagen);

    if ($stmt->execute()) {
        echo "<h1>¡Éxito!</h1><p>Tus datos han sido guardados correctamente.</p>";
        echo '<a href="index.php">Enviar otra noticia</a>';
    } else {
        echo "Error al guardar en la base de datos: " . $stmt->error;
    }
    $stmt->close();
} else {
    echo "Hubo un error subiendo tu archivo de imagen.";
}
$conn->close();
?>