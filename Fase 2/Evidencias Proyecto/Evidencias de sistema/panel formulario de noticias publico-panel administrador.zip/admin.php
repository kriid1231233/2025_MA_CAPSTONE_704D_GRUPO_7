<?php
// session_start(); // Descomenta esta línea si vuelves a poner el login
// if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
//     header('Location: login.php');
//     exit;
// }

// --- CONEXIÓN A LA BASE DE DATOS ---
$servername = "localhost";
$username = "zhwmxmyk_zhwmxmyk";
$password = "*8IS2G2fy6aS@2&g";
$dbname = "zhwmxmyk_form_datos";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) { die("Error de conexión: " . $conn->connect_error); }

// --- CONSULTA PARA OBTENER LOS REGISTROS ---
$sql = "SELECT id, nombre, telefono, noticia, ruta_imagen, fecha_registro FROM registros ORDER BY id DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administrador - Tropezón Tu Diario</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@700&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <style>
        body { 
            font-family: 'Roboto', sans-serif; 
            background-color: #f0f2f5; 
        }
        .header-diario { 
            background-color: #1d4a79; 
            color: white; 
            padding: 1.5rem 0; 
            font-family: 'Roboto Slab', serif; 
        }
        .noticia-card {
            display: flex;
            flex-direction: row;
            background-color: #fff;
            border-radius: .5rem;
            box-shadow: 0 4px 8px rgba(0,0,0,0.05);
            margin-bottom: 1.5rem;
            overflow: hidden; /* Para que la imagen respete el borde redondeado */
        }
        .noticia-img {
            width: 200px;
            height: 100%;
            object-fit: cover;
        }
        .noticia-content {
            padding: 1.5rem;
            flex-grow: 1; /* Para que ocupe el espacio restante */
            display: flex;
            flex-direction: column;
        }
        .noticia-actions {
            margin-left: auto; /* Empuja las acciones a la derecha */
            text-align: right;
        }
        .noticia-resumen {
            flex-grow: 1; /* Empuja las acciones hacia abajo */
        }
    </style>
</head>
<body>
    <header class="header-diario text-center">
        <h1>Panel de Administración</h1>
    </header>
    
    <div class="container my-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="mb-0">Noticias Recibidas</h3>
            </div>

        <?php
        if ($result->num_rows > 0) {
            // --- MOSTRAR CADA REGISTRO EN UNA TARJETA ---
            while($row = $result->fetch_assoc()) {
        ?>
        <div class="noticia-card">
            <img src="<?php echo htmlspecialchars($row["ruta_imagen"]); ?>" alt="Imagen de la noticia" class="noticia-img d-none d-md-block">
            
            <div class="noticia-content">
                <div class="d-flex w-100 justify-content-between">
                    <div>
                        <h5 class="mb-1">Enviado por: <?php echo htmlspecialchars($row["nombre"]); ?></h5>
                        <small class="text-muted">
                            <i class="bi bi-telephone"></i> <?php echo htmlspecialchars($row["telefono"]); ?> | 
                            <i class="bi bi-calendar-event"></i> <?php echo date("d/m/Y H:i", strtotime($row["fecha_registro"])); ?>
                        </small>
                    </div>
                    <div class="noticia-actions">
                        <a href="ver_noticia.php?id=<?php echo $row["id"]; ?>" class="btn btn-info btn-sm mb-2">Ver Noticia</a>
                        <form action="eliminar.php" method="POST" onsubmit="return confirm('¿Estás seguro de que quieres eliminar este registro?');">
                            <input type="hidden" name="id_a_eliminar" value="<?php echo $row["id"]; ?>">
                            <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                        </form>
                    </div>
                </div>
                <hr>
                <p class="noticia-resumen">
                    <?php echo nl2br(htmlspecialchars(substr($row["noticia"], 0, 250))); ?>...
                </p>
            </div>
        </div>
        <?php
            } // Fin del while
        } else {
            echo '<div class="alert alert-info text-center">No hay registros para mostrar.</div>';
        }
        $conn->close();
        ?>
    </div>
</body>
</html>