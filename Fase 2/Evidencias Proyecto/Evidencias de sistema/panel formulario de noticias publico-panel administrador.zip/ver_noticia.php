<?php
// --- 1. CONEXIÓN A LA BASE DE DATOS ---
$servername = "localhost";
$username = "zhwmxmyk_zhwmxmyk";
$password = "*8IS2G2fy6aS@2&g";
$dbname = "zhwmxmyk_form_datos";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) { die("Error de conexión: " . $conn->connect_error); }

// --- 2. CONSULTA PARA OBTENER LA NOTICIA ESPECÍFICA ---
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: admin.php");
    exit();
}
$id_noticia = $_GET['id'];
$stmt = $conn->prepare("SELECT nombre, telefono, noticia, ruta_imagen, fecha_registro FROM registros WHERE id = ?");
$stmt->bind_param("i", $id_noticia);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    echo "No se encontró la noticia.";
    exit();
}
$noticia = $result->fetch_assoc();

// --- Lógica adicional para crear un título dinámico ---
$palabras = explode(' ', $noticia['noticia']);
$titulo = implode(' ', array_slice($palabras, 0, 10));
if (count($palabras) > 10) {
    $titulo .= '...';
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalle de Noticia - Tropezón Tu Diario</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@700&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body { 
            font-family: 'Roboto', sans-serif; 
            background-color: #f8f9fa; 
        }
        .header-diario { 
            background-color: #1d4a79; 
            color: white; 
            padding: 1.5rem 0; 
            font-family: 'Roboto Slab', serif; 
        }
        .article-title {
            font-family: 'Roboto Slab', serif;
            font-size: 2.5rem;
            font-weight: 700;
            line-height: 1.2;
            margin-top: 1.5rem;
        }
        .article-body {
            text-align: justify;
            line-height: 1.8;
            font-size: 1.15rem;
            color: #343a40;
            white-space: pre-wrap;
        }
        .metadata-card {
            background-color: #f0f2f5;
            border: 1px solid #dee2e6;
        }
        .metadata-card .list-group-item {
            background-color: transparent;
            border: none;
        }
        .img-fluid {
            border-radius: .5rem;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <header class="header-diario text-center">
        <h1>Tropezón Tu Diario</h1>
    </header>
    <div class="container my-5">
        <div class="row">
            <main class="col-lg-8">
                <article>
                    <h2 class="article-title"><?php echo htmlspecialchars($titulo); ?></h2>
                    <hr class="my-4">
                    
                    <img src="<?php echo htmlspecialchars($noticia['ruta_imagen']); ?>" alt="Imagen de la noticia" class="img-fluid mb-4">
                    
                    <div class="article-body">
                        <?php echo htmlspecialchars($noticia['noticia']); ?>
                    </div>
                </article>
            </main>

            <aside class="col-lg-4">
                <div class="card metadata-card sticky-top">
                    <div class="card-body">
                        <h5 class="card-title mb-3">Detalles del Envío</h5>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item d-flex align-items-center">
                                <i class="bi bi-person-circle me-3 fs-4"></i>
                                <div>
                                    <strong>Enviado por:</strong><br>
                                    <?php echo htmlspecialchars($noticia['nombre']); ?>
                                </div>
                            </li>
                            <li class="list-group-item d-flex align-items-center">
                                <i class="bi bi-telephone-fill me-3 fs-4"></i>
                                <div>
                                    <strong>Contacto:</strong><br>
                                    <?php echo htmlspecialchars($noticia['telefono']); ?>
                                </div>
                            </li>
                            <li class="list-group-item d-flex align-items-center">
                                <i class="bi bi-calendar-event me-3 fs-4"></i>
                                <div>
                                    <strong>Fecha de Envío:</strong><br>
                                    <?php echo date("d/m/Y H:i", strtotime($noticia['fecha_registro'])); ?>
                                </div>
                            </li>
                             <li class="list-group-item d-flex align-items-center">
                                <i class="bi bi-download me-3 fs-4"></i>
                                <div>
                                    <strong>Archivo Adjunto:</strong><br>
                                    <a href="<?php echo htmlspecialchars($noticia['ruta_imagen']); ?>" download class="btn btn-success btn-sm mt-1">
                                        Descargar Imagen
                                    </a>
                                </div>
                            </li>
                            </ul>
                        <hr class="my-3">
                        <a href="admin.php" class="btn btn-primary w-100">← Volver al Panel</a>
                    </div>
                </div>
            </aside>
        </div>
    </div>
</body>
</html>
<?php
$stmt->close();
$conn->close();
?>