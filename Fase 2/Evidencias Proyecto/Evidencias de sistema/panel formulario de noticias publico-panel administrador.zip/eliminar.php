<?php
// Verificar que se haya enviado un ID
if (isset($_POST['id_a_eliminar']) && !empty($_POST['id_a_eliminar'])) {

    // --- 1. CONEXIÓN A LA BASE DE DATOS ---
    $servername = "localhost";
    $username = "zhwmxmyk_zhwmxmyk";
    $password = "*8IS2G2fy6aS@2&g";
    $dbname = "zhwmxmyk_form_datos";
    
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
      die("Error de conexión: " . $conn->connect_error);
    }

    // --- 2. PREPARAR Y EJECUTAR LA CONSULTA DE ELIMINACIÓN ---
    $id_a_eliminar = $_POST['id_a_eliminar'];
    
    // Usamos una sentencia preparada para seguridad
    $stmt = $conn->prepare("DELETE FROM registros WHERE id = ?");
    $stmt->bind_param("i", $id_a_eliminar); // "i" porque el ID es un entero

    if ($stmt->execute()) {
        // Si la eliminación es exitosa, redirigir de vuelta al panel de admin
        header("Location: admin.php");
        exit();
    } else {
        echo "Error al eliminar el registro: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();

} else {
    // Si no se envió un ID, redirigir también
    header("Location: admin.php");
    exit();
}
?>